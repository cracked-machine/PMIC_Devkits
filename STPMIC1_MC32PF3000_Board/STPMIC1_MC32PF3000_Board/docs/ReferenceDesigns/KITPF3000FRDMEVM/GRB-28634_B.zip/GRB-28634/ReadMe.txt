README for GRB-28634_B.zip

Company Part Number: 170-28634 REV B

Date: Thu, 12 Feb 2015 22:22:47 GMT

Freescale Semiconductor
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : [full_name]
Work Phone          : 512-895-XXXX
Email               : [email]@freescale.com

CAD Manager
===========
Company Contact     : Raymond Villalobos
Work Phone          : 512-895-6081
Email               : Raymond.Villalobos@freescale.com

Manufacturing Program Manager
=============================
Company Contact     : Laura Moreno
Work Phone          : +52(33)3283-2100x2331
Email               : B48993@freescale.com

Product Engineer
================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33)3283-2100x2267
Email               : b49008@freescale.com
